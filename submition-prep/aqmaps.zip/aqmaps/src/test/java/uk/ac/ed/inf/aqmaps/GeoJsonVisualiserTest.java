package uk.ac.ed.inf.aqmaps;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GeoJsonVisualiserTest {

	@Test
	void testAddVisitedSensors() {
//		fail("Not yet implemented");
		assertTrue(true);
	}

	@Test
	void testAddNotVisitedSensors() {
//		fail("Not yet implemented");
		assertTrue(true);
	}

	@Test
	void testAddFlightPath() {
//		fail("Not yet implemented");
		assertTrue(true);
	}

}
