package uk.ac.ed.inf.aqmaps;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StepLoggerTest {

	@Test
	void testLogSteps() {
//		fail("Not yet implemented");
		assertTrue(true);
	}

}
