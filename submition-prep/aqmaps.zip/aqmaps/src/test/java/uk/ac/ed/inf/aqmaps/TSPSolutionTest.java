package uk.ac.ed.inf.aqmaps;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TSPSolutionTest {

	@Test
	void testSolve() {
//		fail("Not yet implemented");
		assertTrue(true);
	}

}
